require(mpo)
returns = midcap.ts[, 1:10]
mathGmv(returns)
